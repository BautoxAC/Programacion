import constructistas.AVL.ArbolAVL;
import lineales.dinamicas.Cola;
import lineales.dinamicas.Lista;
import lineales.dinamicas.Pila;
import lineales.dinamicas.NODO.Nodo;

public class Xd {

    public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        int[] arr =  {30, 15, 40,10,25,35,50,5};
        if(false){
            arbol.getBanana();
        }
        System.out.println("hola");
    }

}